import sentencepiece as spm
import torch
from torch.nn.utils.rnn import pad_sequence

class Tokenizer:
    def __init__(self, model_file: str, max_length: int = 512):
        self.sp = spm.SentencePieceProcessor(model_file=model_file)
        self.max_length = max_length
        self.pad_token_id = self.sp.piece_to_id("[PAD]")
        self.cls_token_id = self.sp.piece_to_id("[CLS]")
        self.sep_token_id = self.sp.piece_to_id("[SEP]")

    def tokenize(self, text: str):

        tokens = self.sp.encode(text, out_type=int)
        tokens = [self.cls_token_id] + tokens + [self.sep_token_id]
        if len(tokens) > self.max_length:
            tokens = tokens[:self.max_length - 1] + [self.sep_token_id]
        return tokens

    def batch_tokenize(self, texts: list[str]):
        tokenized_texts = []
        attention_masks = []

        for text in texts:
            tokens = self.tokenize(text)
            tokenized_texts.append(torch.tensor(tokens))
            attention_masks.append(torch.tensor([1] * len(tokens)))

        tokenized_texts = pad_sequence(
            tokenized_texts, batch_first=True, padding_value=self.pad_token_id
        )
        attention_masks = pad_sequence(
            attention_masks, batch_first=True, padding_value=0
        )

        return tokenized_texts, attention_masks
