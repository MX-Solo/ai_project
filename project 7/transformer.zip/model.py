import torch
import math
import torch.nn.functional as F
import torch.nn as nn


class PositionaEmbedding(torch.nn.Module):
    def __init__(self,d_model,max_len=120):
        super().__init__()
        pe= torch.zeros(max_len,d_model).float()
        pe.required_grad= False

        for pos in range(max_len):
            for i in range(0,d_model,2):
                pe[pos,i] = math.sin(pos/(10000 ** ((2*i)/d_model)))
                pe[pos, i] = math.cos(pos / (10000 ** ((i+1) / d_model)))

        self.pe= pe.unsqueeze(0)

    def forward(self,x):
        return self.pe
    
class ModelEmbedding(torch.nn.Module):

    def __init__(self,vocab_size,embed_size,seq_len=128,dropout=0.1):
        super().__init__()
        self.embed_size =embed_size
        self.token = torch.nn.Embedding(vocab_size,embed_size,padding_idx=0)
        self.segment= torch.nn.Embedding(3,embed_size,padding_idx=0)
        self.position = PositionaEmbedding(d_model=embed_size, max_len=seq_len)
        self.dropout= torch.nn.Dropout(p=dropout)

    def forward(self,sequence,segment_label):
        x= self.token(sequence) + self.position(sequence) + self.segment(segment_label)
        return self.dropout(x)
    
    
class MultiHeadedAttention(torch.nn.Module):
    def __init__(self,heads,d_model,dropout=0.1):
        super(MultiHeadedAttention,self).__init__()
        assert d_model% heads ==0
        self.d_k= d_model// heads
        self.heads= heads
        self.dropout= torch.nn.Dropout(dropout)

        self.query= torch.nn.Linear(d_model,d_model)
        self.key = torch.nn.Linear(d_model, d_model)
        self.value = torch.nn.Linear(d_model, d_model)

        self.output_linear= torch.nn.Linear(d_model,d_model)

    def forward(self,query,key,value,mask):

        query = self.query(query)
        key = self.key(key)
        value = self.query(value)

        query = query.view(query.shape[0],-1,self.heads,self.d_k).permute(0,2,1,3)
        key = key.view(key.shape[0], -1, self.heads, self.d_k).permute(0, 2, 1, 3)
        value = value.view(value.shape[0], -1, self.heads, self.d_k).permute(0, 2, 1, 3)

        scores = torch.matmul(query,key.permute(0,1,3,2))/ math.sqrt(query.size(-1))

        scores = scores.masked_fill(mask == 0, -1e9)

        weights = F.softmax(scores,dim=-1)
        weights = self.dropout(weights)

        context= torch.matmul(weights,value)
        context= context.permute(0,2,1,3).contiguous().view(context.shape[0], -1, self.heads * self.d_k)

        return self.output_linear(context)
    
    
class FeedForward(torch.nn.Module):
    def __init__(self,d_model, middle_dim=2048, dropout=0.1):
        super(FeedForward,self).__init__()
        self.fc1 = nn.Linear(d_model,middle_dim)
        self.fc2= nn.Linear(middle_dim,d_model)
        self.activation= nn.GELU()
        self.dropout= nn.Dropout(dropout)

    def forward(self,x):
        x= self.activation(self.fc1(x))
        x = self.fc2(self.dropout(x))
        return x


class EncoderLayer(torch.nn.Module):
    def __init__(
        self,
        d_model=768,
        heads=12,
        feed_forward_hidden=768 * 4,
        dropout=0.1
        ):
        super(EncoderLayer, self).__init__()
        self.layernorm = torch.nn.LayerNorm(d_model)
        self.self_multihead = MultiHeadedAttention(heads, d_model)
        self.feed_forward = FeedForward(d_model, middle_dim=feed_forward_hidden)
        self.dropout = torch.nn.Dropout(dropout)
        
    def forward(self, embeddings, mask):

        interacted = self.dropout(self.self_multihead(embeddings, embeddings, embeddings, mask))
        interacted = self.layernorm(interacted + embeddings)
        feed_forward_out = self.dropout(self.feed_forward(interacted))
        encoded = self.layernorm(feed_forward_out + interacted)
        return encoded
    
class Model(torch.nn.Module):

    def __init__(self,vocab_size,d_model=768,n_layers=12, heads=12,dropout=0.1,class_num=5):
        super().__init__()
        self.d_model = d_model
        self.n_layers = n_layers
        self.heads = heads

        self.feed_forward_hidden = 4 * self.d_model
        self.embedding= ModelEmbedding(vocab_size= vocab_size,embed_size = d_model)

        self.encoder_blocks = torch.nn.ModuleList(
            [EncoderLayer(d_model,heads,d_model*4,dropout) for _ in range(self.n_layers)]
        )
        self.classifier = nn.Linear(d_model, class_num)
        self.m = nn.Softmax(dim=1)

    def forward(self,x,segment_info):
        mask = (x>0).unsqueeze(1).repeat(1,x.size(1),1).unsqueeze(1)

        x=self.embedding(x,segment_info)
        for encoder in self.encoder_blocks:
            x= encoder.forward(x,mask)  
        x= x.mean(dim=1)
        x= self.m(self.classifier(x))
        return x
    
