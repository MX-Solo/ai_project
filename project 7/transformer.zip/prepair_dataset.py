import pandas as pd
import torch
from torch.utils.data import Dataset

class TextClassificationDataset(Dataset):
    def __init__(self, csv_file: str, tokenizer, max_length: int = 128):

        self.data = pd.read_csv(csv_file)
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):

        row = self.data.iloc[idx]
        text, label = row['comment'], row['label']

        # Tokenize the text
        tokens = self.tokenizer.tokenize(text)

        # Truncate or pad to max length
        if len(tokens) > self.max_length:
            tokens = tokens[:self.max_length - 1] + [self.tokenizer.sep_token_id]
        elif len(tokens) < self.max_length:
            padding_length = self.max_length - len(tokens)
            tokens = [self.tokenizer.cls_token_id] + tokens + [self.tokenizer.sep_token_id] + [0] * padding_length

        input_ids = tokens[:self.max_length]
        attention_mask = [1] * len(input_ids) + [0] * (self.max_length - len(input_ids))

        return {
            'input_ids': torch.tensor(input_ids, dtype=torch.long),
            'attention_mask': torch.tensor(attention_mask, dtype=torch.long),
            'label': torch.tensor(label, dtype=torch.long)
        }
