import glob
import sentencepiece as spm


folder_path = "dataset/wiki-farsi"
files = glob.glob(f"{folder_path}/*.txt")  

input_files = ','.join(files)

spm.SentencePieceTrainer.train(
    input=input_files,       
    model_prefix='bpe_tokenizer',     
    vocab_size=30000,                 
    model_type='bpe',                 
    pad_id=0,                         
    unk_id=1,                         
    bos_id=2,                         
    eos_id=3, 
    user_defined_symbols=['[CLS]', '[SEP]', '[MASK]']
)

sp = spm.SentencePieceProcessor(model_file='bpe_tokenizer.model')


text = "Hello, how are you?"
encoded = sp.encode(text, out_type=int)  
decoded = sp.decode(encoded)            

print("Original Text:", text)
print("Encoded IDs:", encoded)
print("Decoded Text:", decoded)
