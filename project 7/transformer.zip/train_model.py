from model import Model
from tokenizer import Tokenizer
from prepair_dataset import TextClassificationDataset
from torch.utils.data import DataLoader
import torch
import torch.nn.functional as F
from torch.optim import Adam
from torch.nn import CrossEntropyLoss
from tqdm import tqdm



tokenizer = Tokenizer(model_file="bpe_tokenizer.model")


trasin_dataset = TextClassificationDataset(csv_file="dataset/persian-sentiment/train.csv", tokenizer=tokenizer)
val_dataset = TextClassificationDataset(csv_file="dataset/persian-sentiment/validation.csv", tokenizer=tokenizer)

train_loader = DataLoader(trasin_dataset, batch_size=2, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=2, shuffle=False)

vocab_size = 30000
model = Model(vocab_size=vocab_size, d_model=128, n_layers=2, heads=2, dropout=0.1, class_num=2)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)


epochs=3
batch_size=16
lr=1e-4


criterion = CrossEntropyLoss()
optimizer = Adam(model.parameters(), lr=lr)


def eval_model(model, val_loader):
    model.eval()
    val_loss = 0.0
    val_correct = 0
    val_total = 0

    with torch.no_grad():
        for batch in tqdm(val_loader, desc="Validating"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['label'].to(device)
            labels = F.one_hot(labels, num_classes=2).to(dtype=torch.float16)

            # Forward pass
            segment_info = torch.zeros_like(input_ids).to(device)
            outputs = model(input_ids, segment_info)

            # Compute loss
            logits = outputs

            loss = criterion(logits, labels)
            val_loss += loss.item()

            # Compute accuracy
            preds = torch.argmax(logits, dim=-1)
            val_correct += (preds == labels).sum().item()
            val_total += labels.size(0)

    return val_correct / val_total, val_loss

model.train()
for epoch in range(epochs):
    
    epoch_loss = 0.0
    correct_predictions = 0
    total_predictions = 0

    for batch in tqdm(train_loader, desc=f"Epoch {epoch+1}/{epochs}"):
        
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['label'].to(device)
        labels = F.one_hot(labels, num_classes=2).to(dtype=torch.float16)
        optimizer.zero_grad()

        segment_info = torch.zeros_like(input_ids).to(device)
        outputs = model(input_ids, segment_info)

        logits = outputs
        loss = criterion(logits, labels)
        epoch_loss += loss.item()

        loss.backward()
        optimizer.step()

        preds = torch.argmax(logits, dim=-1)
        correct_predictions += (preds == labels).sum().item()
        total_predictions += labels.size(0)

    
    accuracy, val_loss = eval_model(model, val_loader)
    print(f"Epoch {epoch+1}: Loss = {val_loss:.4f}, Accuracy = {accuracy:.4f}")